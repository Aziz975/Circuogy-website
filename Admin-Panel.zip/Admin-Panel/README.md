# Admin Panel Backend (Express + MySQL)

Admin login, change password, and blog CRUD (public read, admin-only write).

## Setup

```bash
npm install
cp .env.example .env        # Windows: copy .env.example .env
# fill in DB_PASSWORD, FRONTEND_ORIGIN and JWT_SECRET (see below)
npm run db:init             # creates database, tables, default admin
npm run dev                 # http://localhost:5000
```

Generate `JWT_SECRET`:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Default admin (change it right away via Change Password):
`admin@example.com` / `Blog@AhkrUMY7jp4f`

Create or reset an admin: `npm run create-admin -- you@example.com "NewStrongPass"`

## API

| Method | Path | Auth | Body |
|---|---|---|---|
| POST | /api/auth/login | – | `{ email, password }` |
| POST | /api/auth/change-password | – | `{ email, currentPassword, newPassword }` |
| GET | /api/auth/me | Bearer | – |
| GET | /api/blogs | – | – |
| GET | /api/blogs/:slug | – | – |
| POST | /api/blogs | Bearer | `{ title, excerpt, content, cover_image, category }` |
| PUT | /api/blogs/:id | Bearer | same as POST |
| DELETE | /api/blogs/:id | Bearer | – |

Responses: `{ success, message, data }`. Login returns `data: { token, admin }`.
Send the token as `Authorization: Bearer <token>`.
