
import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import pool from "../config/db.js";

const router = express.Router();

// Authenticate the admin using the existing login token.
async function authenticateAdmin(req, res, next) {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({
        message: "Please log in to continue.",
      });
    }

    const token = authHeader.slice(7);
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const adminId = decoded.id ?? decoded.sub;

    if (!adminId || !/^\d+$/.test(String(adminId))) {
      return res.status(401).json({
        message: "Invalid authentication token.",
      });
    }

    const [admins] = await pool.execute(
      "SELECT id, email FROM admins WHERE id = ? LIMIT 1",
      [adminId]
    );

    if (admins.length === 0) {
      return res.status(401).json({
        message: "Admin account not found.",
      });
    }

    req.admin = admins[0];
    next();
  } catch (error) {
    if (
      error.name === "TokenExpiredError" ||
      error.name === "JsonWebTokenError"
    ) {
      return res.status(401).json({
        message: "Your session is invalid or expired. Please log in again.",
      });
    }

    console.error("Admin authentication error:", error);

    return res.status(500).json({
      message: "Authentication failed.",
    });
  }
}

// POST /api/admin/change-password
router.post("/change-password", authenticateAdmin, async (req, res) => {
  try {
    const { currentPassword, newPassword, confirmPassword } = req.body;

    if (
      typeof currentPassword !== "string" ||
      typeof newPassword !== "string" ||
      typeof confirmPassword !== "string" ||
      !currentPassword ||
      !newPassword ||
      !confirmPassword
    ) {
      return res.status(400).json({
        message: "All password fields are required.",
      });
    }

    // bcrypt supports a maximum input length of 72 bytes.
    if (Buffer.byteLength(newPassword, "utf8") > 72) {
      return res.status(400).json({
        message: "New password must not exceed 72 UTF-8 bytes.",
      });
    }

    if (newPassword.length < 12) {
      return res.status(400).json({
        message: "New password must be at least 12 characters long.",
      });
    }

    if (newPassword !== confirmPassword) {
      return res.status(400).json({
        message: "New password and confirmation do not match.",
      });
    }

    // Fetch the authenticated admin's password hash.
    const [rows] = await pool.execute(
      "SELECT password FROM admins WHERE id = ? LIMIT 1",
      [req.admin.id]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        message: "Admin account not found.",
      });
    }

    const passwordMatches = await bcrypt.compare(
      currentPassword,
      rows[0].password
    );

    if (!passwordMatches) {
      return res.status(400).json({
        message: "Current password is incorrect.",
      });
    }

    const isSamePassword = await bcrypt.compare(
      newPassword,
      rows[0].password
    );

    if (isSamePassword) {
      return res.status(400).json({
        message: "Choose a password different from your current password.",
      });
    }

    const newPasswordHash = await bcrypt.hash(newPassword, 12);

    const [result] = await pool.execute(
      "UPDATE admins SET password = ? WHERE id = ?",
      [newPasswordHash, req.admin.id]
    );

    if (result.affectedRows !== 1) {
      return res.status(500).json({
        message: "Password could not be updated. Please try again.",
      });
    }

    return res.status(200).json({
      message: "Password changed successfully.",
    });
  } catch (error) {
    console.error("Change password error:", error);

    return res.status(500).json({
      message: "Unable to change password. Please try again.",
    });
  }
});

export default router;
