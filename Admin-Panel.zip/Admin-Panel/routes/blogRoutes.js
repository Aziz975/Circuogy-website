
import { Router } from "express";
import upload from "../middleware/upload.js";
import { requireAdmin } from "../middleware/auth.js";
import * as c from "../controllers/blogController.js";

const router = Router();

// Public route — no authentication required
router.get("/public", c.getPublished);

// Admin-only routes
router.get("/", requireAdmin, c.getAll);
router.post("/", requireAdmin, upload.single("image"), c.create);
router.put("/:id", requireAdmin, upload.single("image"), c.update);
router.delete("/:id", requireAdmin, c.remove);

export default router;
