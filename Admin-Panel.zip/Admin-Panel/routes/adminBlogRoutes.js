
import { Router } from "express";
import * as blog from "../controllers/blogController.js";
import { requireAdmin } from "../middleware/auth.js";

const router = Router();

// Verify authentication middleware.
if (typeof requireAdmin !== "function") {
  throw new TypeError("requireAdmin is not exported as a function");
}

// Protect every admin route.
router.use(requireAdmin);

// Validate numeric IDs.
router.param("id", (req, res, next, id) => {
  if (!/^\d+$/.test(id)) {
    return res.status(404).json({
      message: "Blog post not found.",
    });
  }
  next();
});

// Verify controller exports before registering routes.
for (const name of ["getAll", "create", "getById", "update", "remove"]) {
  if (typeof blog[name] !== "function") {
    throw new TypeError(
      `blogController.js must export a function named "${name}"`
    );
  }
}

router.get("/", blog.getAll);
router.post("/", blog.create);
router.get("/:id", blog.getById);
router.put("/:id", blog.update);
router.delete("/:id", blog.remove);

export default router;
