
import express from "express";
import helmet from "helmet";
import cors from "cors";
import morgan from "morgan";
import cookieParser from "cookie-parser";
import path from "node:path";
import { fileURLToPath } from "node:url";

import env from "./config/env.js";
import { apiLimiter } from "./middleware/rateLimiters.js";
import { notFound, errorHandler } from "./middleware/errorHandler.js";
import authRoutes from "./routes/authRoutes.js";
import blogRoutes from "./routes/blogRoutes.js";
import adminBlogRoutes from "./routes/adminBlogRoutes.js";

// ES module equivalent of __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Needed behind Nginx / Render / Railway
if (env.isProd) {
  app.set("trust proxy", 1);
}

// Security headers
app.use(helmet());

// CORS configuration
app.use(
  cors({
    origin(origin, cb) {
      // Allow same-origin requests and non-browser tools.
      if (!origin || env.clientOrigins.includes(origin)) {
        return cb(null, true);
      }

      return cb(new Error("Origin not allowed by CORS"));
    },
    credentials: true,
  })
);

// Request parsing
app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());

// Development logging
if (!env.isProd) {
  app.use(morgan("dev"));
}

// Serve frontend static files
app.use(express.static(path.join(__dirname, "public")));

// Serve uploaded images
app.use(
  "/uploads",
  express.static(path.join(__dirname, "uploads"))
);

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

// API rate limiting
app.use("/api", apiLimiter);

// Authentication routes
app.use("/api/auth", authRoutes);

// Public blog routes
app.use("/api/blogs", blogRoutes);

// Admin blog routes
app.use("/api/admin/blogs", adminBlogRoutes);

// 404 handler
app.use(notFound);

// Central error handler
app.use(errorHandler);

export default app;
