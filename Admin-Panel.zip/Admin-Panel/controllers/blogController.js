
import db from "../config/db.js";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// ES module path setup
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Generate URL-friendly slugs
const slugify = (value) =>
  value
    .toLowerCase()
    .trim()
    .replace(/['’]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "") || "blog";

// Generate a unique slug
const uniqueSlug = async (title, ignoreId = null) => {
  const base = slugify(title);
  let slug = base;
  let i = 2;

  while (true) {
    const [rows] = await db.query(
      "SELECT id FROM blogs WHERE slug = ? AND id <> ? LIMIT 1",
      [slug, ignoreId ?? 0]
    );

    if (rows.length === 0) {
      return slug;
    }

    slug = `${base}-${i++}`;
  }
};

// Remove an uploaded image safely
const removeFile = (imgPath) => {
  if (!imgPath || !imgPath.startsWith("/uploads/")) return;

  const uploadRoot = path.resolve(__dirname, "..", "uploads");
  const filePath = path.resolve(__dirname, "..", imgPath.slice(1));

  // Prevent deleting files outside the uploads directory
  if (
    filePath !== uploadRoot &&
    !filePath.startsWith(uploadRoot + path.sep)
  ) {
    return;
  }

  fs.unlink(filePath, (err) => {
    if (err && err.code !== "ENOENT") {
      console.error("Failed to remove blog image:", err);
    }
  });
};

// ADMIN: Get all blogs
export const getAll = async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT * FROM blogs ORDER BY created_at DESC"
    );

    return res.json(rows);
  } catch (err) {
    console.error("GET ALL BLOGS ERROR:", err);

    return res.status(500).json({
      message: "Failed to fetch blogs",
    });
  }
};

// ADMIN: Get one blog by ID
export const getById = async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT * FROM blogs WHERE id = ? LIMIT 1",
      [req.params.id]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        message: "Blog not found",
      });
    }

    return res.json(rows[0]);
  } catch (err) {
    console.error("GET BLOG BY ID ERROR:", err);

    return res.status(500).json({
      message: "Failed to fetch blog",
    });
  }
};

// PUBLIC: Get published blogs only
export const getPublished = async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT * FROM blogs WHERE status = 'published' ORDER BY created_at DESC"
    );

    return res.json(rows);
  } catch (err) {
    console.error("GET PUBLISHED BLOGS ERROR:", err);

    return res.status(500).json({
      message: "Failed to fetch blogs",
    });
  }
};

// ADMIN: Create a blog
export const create = async (req, res) => {
  try {
    const {
      title,
      category,
      author,
      date,
      description,
      content,
      status,
    } = req.body;

    if (
      typeof title !== "string" ||
      !title.trim() ||
      typeof category !== "string" ||
      !category.trim()
    ) {
      return res.status(400).json({
        message: "Title and category are required",
      });
    }

    const slug = await uniqueSlug(title.trim());
    const image = req.file
      ? `/uploads/blogs/${req.file.filename}`
      : null;

    const publicationDate = date?.trim() || null;

    const [result] = await db.query(
      `INSERT INTO blogs
        (title, slug, category, author, publication_date,
         description, content, image, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        title.trim(),
        slug,
        category.trim(),
        typeof author === "string" ? author.trim() : "",
        publicationDate,
        typeof description === "string" ? description.trim() : "",
        typeof content === "string" ? content : "",
        image,
        status === "published" ? "published" : "draft",
      ]
    );

    const [rows] = await db.query(
      "SELECT * FROM blogs WHERE id = ? LIMIT 1",
      [result.insertId]
    );

    return res.status(201).json(rows[0]);
  } catch (err) {
    console.error("CREATE BLOG ERROR:", err);

    return res.status(500).json({
      message: "Failed to create blog",
      ...(process.env.NODE_ENV !== "production" && {
        error: err.message,
        code: err.code,
      }),
    });
  }
};

// ADMIN: Update a blog
export const update = async (req, res) => {
  try {
    const { id } = req.params;

    const [existing] = await db.query(
      "SELECT * FROM blogs WHERE id = ? LIMIT 1",
      [id]
    );

    if (existing.length === 0) {
      return res.status(404).json({
        message: "Blog not found",
      });
    }

    const old = existing[0];

    const {
      title,
      category,
      author,
      date,
      description,
      content,
      status,
      removeImage,
    } = req.body;

    if (
      typeof title !== "string" ||
      !title.trim() ||
      typeof category !== "string" ||
      !category.trim()
    ) {
      return res.status(400).json({
        message: "Title and category are required",
      });
    }

    const slug =
      title.trim() !== old.title
        ? await uniqueSlug(title.trim(), id)
        : old.slug;

    let image = old.image;

    if (req.file) {
      image = `/uploads/blogs/${req.file.filename}`;
    } else if (removeImage === "true") {
      image = null;
    }

    await db.query(
      `UPDATE blogs
       SET title = ?, slug = ?, category = ?, author = ?,
           publication_date = ?, description = ?, content = ?,
           image = ?, status = ?
       WHERE id = ?`,
      [
        title.trim(),
        slug,
        category.trim(),
        typeof author === "string" ? author.trim() : "",
        date?.trim() || null,
        typeof description === "string" ? description.trim() : "",
        typeof content === "string" ? content : "",
        image,
        status === "published" ? "published" : "draft",
        id,
      ]
    );

    // Remove the old image only after the database update succeeds.
    if (req.file || removeImage === "true") {
      removeFile(old.image);
    }

    const [rows] = await db.query(
      "SELECT * FROM blogs WHERE id = ? LIMIT 1",
      [id]
    );

    return res.json(rows[0]);
  } catch (err) {
    console.error("UPDATE BLOG ERROR:", err);

    return res.status(500).json({
      message: "Failed to update blog",
      ...(process.env.NODE_ENV !== "production" && {
        error: err.message,
        code: err.code,
      }),
    });
  }
};

// ADMIN: Delete a blog
export const remove = async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT image FROM blogs WHERE id = ? LIMIT 1",
      [req.params.id]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        message: "Blog not found",
      });
    }

    await db.query("DELETE FROM blogs WHERE id = ?", [
      req.params.id,
    ]);

    removeFile(rows[0].image);

    return res.json({
      message: "Blog deleted successfully",
    });
  } catch (err) {
    console.error("DELETE BLOG ERROR:", err);

    return res.status(500).json({
      message: "Failed to delete blog",
    });
  }
};
